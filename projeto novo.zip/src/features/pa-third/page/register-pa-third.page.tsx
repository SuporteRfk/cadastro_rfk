import { FormLayout, PageLayout } from "@/components";
import {Building as PAThirdIcon} from "lucide-react";

export const RegisterPAThird = () => {
    return(
        <PageLayout>
            <FormLayout titleForm="P.A Terceiro" iconForm={PAThirdIcon}>
         
            </FormLayout>
        </PageLayout>
    );
};