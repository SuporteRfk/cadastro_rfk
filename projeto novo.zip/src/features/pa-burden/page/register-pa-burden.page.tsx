import { FormLayout, PageLayout } from "@/components";
import {Boxes as BurdenIcon} from "lucide-react";

export const RegisterPABurden = () => {
    return(
        <PageLayout>
            <FormLayout titleForm="P.A Fardo" iconForm={BurdenIcon}>
         
            </FormLayout>
        </PageLayout>
    );
};