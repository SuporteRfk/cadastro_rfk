import { FormLayout, PageLayout } from "@/components";
import {PackageOpen as PAIcon} from "lucide-react";

export const RegisterPACopacker = () => {
    return(
        <PageLayout>
            <FormLayout titleForm="P.A Copacker" iconForm={PAIcon}>
         
            </FormLayout>
        </PageLayout>
    );
};