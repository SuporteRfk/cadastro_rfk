import { FormLayout, PageLayout } from "@/components";
import { Factory as SuppliersIcon} from "lucide-react";

export const RegisterSupplier = () => {
    return(
        <PageLayout>
            <FormLayout titleForm="Fornecedores" iconForm={SuppliersIcon}>
         
            </FormLayout>
        </PageLayout>
    );
};