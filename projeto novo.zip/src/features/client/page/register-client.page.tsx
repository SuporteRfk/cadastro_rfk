import { PageLayout } from "@/components";


export const RegisterClientPage = () => {
    return(
        <PageLayout>
            <form>
                
            </form>
        </PageLayout>
    );
};