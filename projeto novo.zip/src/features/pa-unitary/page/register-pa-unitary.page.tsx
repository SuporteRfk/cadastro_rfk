import { FormLayout, PageLayout } from "@/components";
import {Box as UnitaryIcon} from "lucide-react";

export const RegisterPAUnitary = () => {
    return(
        <PageLayout>
            <FormLayout titleForm="P.A Unitário" iconForm={UnitaryIcon}>
         
            </FormLayout>
        </PageLayout>
    );
};