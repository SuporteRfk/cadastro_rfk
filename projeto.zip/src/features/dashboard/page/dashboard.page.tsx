import { Sidebar } from "@/components/menu/menu-desktop.components"
import { MenuMobile } from "@/components/menu/menu-mobile.components"

export const DashboardPage = () => {
    return(
        <main className="w-full h-screen bg-bg">
            <Sidebar/>
            <MenuMobile/>
        </main>
    )
}