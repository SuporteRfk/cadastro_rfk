import { Dispatch, ReactNode, SetStateAction, createContext, useContext, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { AuthContext } from "./auth.context";
import { menuCommon, menuController } from "@/data/menus";
import {MenuItem} from "@/interfaces";

interface INavigationContextType {
    isMenuOpen: boolean;                                         // Indica se o Menu/Sidebar está aberto
    toggleOpenMenu: () => void;                                  // Função para abrir/fechar Menu/Sidebar
    handleCategoryClick: (categoryLabel:string) => void;         // Função para setar qual categoria está ativa
    activeCategory: string | null;                               // Infica a categoria ativa/selecionada                       
    handleNavigate: (path:string) => void;                       // Função para fazer navegação das rotas 
    isMenuRouteActive: (path:string) => boolean;                 // Função para ativar os botões do menu de acordo com rota da url
    menus: MenuItem[];                                           // Lista de items do menu
    lengthMenuCommom: number;                                    // Tamanho da lista de opções de menu do usuario padrão/comum
    resetPathsMenusAndNavigateDashboard: () => void;             // Funçao para voltar para dashboard e resetar os states de navegação
    handleSidebarTransitionEnd: () => void; 
    setIsMenuOpen: Dispatch<SetStateAction<boolean>>;
 }


export const NavigationContext = createContext<INavigationContextType>({
    isMenuOpen: false,
    toggleOpenMenu: async () => {},
    handleCategoryClick: (_categoryLabel) => {},
    activeCategory: null,
    handleNavigate: (_path) => {},
    isMenuRouteActive: (_path) => false,
    menus: menuCommon,
    lengthMenuCommom: menuCommon.length,
    resetPathsMenusAndNavigateDashboard: () => {},
    handleSidebarTransitionEnd: () => {},
    setIsMenuOpen: () => {}
});

export const NavigationProvider = ({children}:{children:ReactNode}) => {
    const location = useLocation(); // Usado para detectar rota atual automaticamente
    const [activeCategory, setActiveCategory] = useState<string | null>(null);
    const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false); 
    const [isMenuFullyOpen, setIsMenuFullyOpen] = useState(false); // para controlar se a transição do texto na abertura do menu

    const {user} = useContext(AuthContext);
    const navigate = useNavigate();

    // Alternar entre expandido e recolhido
    const toggleOpenMenu = ():void => {
        if(isMenuOpen){
            setIsMenuOpen(false);
            setIsMenuFullyOpen(false);
        }else {
            setIsMenuOpen(true);
        }
    };

    // Ao clicar em uma rota fará a navegação
    const handleNavigate = (path: string):void => {
        navigate(path);
    };


    // reseta os path setados e faz a navegação para dashboard
    const resetPathsMenusAndNavigateDashboard = (): void => {
        setActiveCategory(null);
        navigate("/dashboard");
    };

    
    // Verificar se o caminho da url é o mesmo da opcao no menu. Se aquela opção está ativa
    const isMenuRouteActive = (path: string):boolean => {
        return location.pathname === path;
    }

    // Ao clicar em uma categoria (abre ou fecha submenu)
    const handleCategoryClick = (categoryLabel: string) => {
        if (activeCategory === categoryLabel) {
            setActiveCategory(null); // Fecha se já estiver aberto
        } else {
            setActiveCategory(categoryLabel); // Abre novo submenu
        }
    };


    const handleSidebarTransitionEnd = () => {
        if(isMenuOpen) {
            setIsMenuFullyOpen(true); // Só setar true se abriu totalmente
        }
    };

    const menus = user?.access_approver ? [...menuCommon, ...menuController] : menuCommon;  //Escolher qual menu renderizar
    const lengthMenuCommom = menuCommon.length; //Pegar tamanho da lista de navegação do menu comum para adicionar uma borda de separação
    
    return (
        <NavigationContext.Provider
            value={{
                isMenuOpen,
                toggleOpenMenu,
                handleCategoryClick,
                activeCategory,
                handleNavigate,
                isMenuRouteActive,
                menus,
                lengthMenuCommom,
                resetPathsMenusAndNavigateDashboard,
                handleSidebarTransitionEnd,
                setIsMenuOpen
        }}  
        >
            {children}
        </NavigationContext.Provider>
    )
};
