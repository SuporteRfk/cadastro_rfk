import { Dialog, DialogContent, DialogDescription, DialogHeader } from "@/components/ui/dialog";
import { ModalRequestActions } from "./moda-request-actions.components";
import { ModalRequestRouter } from "./modal-request-router.components";
import { FormStateType, IViewRequest } from "@/interfaces";
import { DialogTitle } from "@radix-ui/react-dialog";
import { useState } from "react";
import { Badge } from "../ui";


interface ModalRequestProps {
  open: boolean;
  onClose: () => void;
  request: IViewRequest;
  isTheRouteOfChange: boolean;
}

const styleBadge = {
    "Pendente": "pending",
    "Em Revisão": "review",
    "Negado": "denied",
    "Aprovado": "approved"
} as const;

export const ModalRequest = ({ open, onClose, request, isTheRouteOfChange }: ModalRequestProps) => {
    const [mode, setMode] = useState<FormStateType>("viewing");
    const [loadingModal, setLoadingModal] = useState<boolean>(false);


    return (
        <Dialog open={open} onOpenChange={onClose}>
            <div className="relative">
                <DialogContent className="max-w-5xl h-screen max-h-[90vh]">
                    <DialogHeader>
                        <DialogTitle className="flex flex-row items-center gap-2 text-lg font-bold text-text-strong">
                            Solicitação #{request.id}
                            <Badge variant={styleBadge[request.status]} className="w-[100px] mr-4">{request.status}</Badge>
                        </DialogTitle>
                         <DialogDescription>Detalhes da Solicitação</DialogDescription>
                    </DialogHeader>
                    {/* Formulário dinâmico */}
                    <ModalRequestRouter 
                        request={request} 
                        mode={mode} 
                        setLoadingModal={setLoadingModal} 
                        isTheRouteOfChange={isTheRouteOfChange} 
                        loadingModal={loadingModal}
                        setMode={setMode}
                    />
                    {/* Ações (editar, aprovar, etc.) */}
                    {!loadingModal && 
                         <ModalRequestActions request={request} mode={mode} setMode={setMode} isTheRouteOfChange={isTheRouteOfChange}/>
                    }
                </DialogContent>
            </div>
        </Dialog>
    );
};





                    
                    
        
  

    