import { FieldValues, Path, UseFormReturn } from "react-hook-form";
import { FormSection } from "./form-section.components";
import { TbNumber as NCMIcon} from "react-icons/tb";
import { Input, InputWithMask } from "../inputs";
import { FormStateType } from "@/interfaces";
import {
    Ruler as UnitMeasureIcon,
    Landmark as TaxIcon,
    Crown as MarkIcon,
    Cherry as FlavorIcon
} from "lucide-react";


interface FormProductAttributesProps<T extends FieldValues> {
    mode?: FormStateType; // 'editing' | 'viewing' | 'reviewing';
    methods: UseFormReturn<T>;
    showSecondUnitMeasure?: boolean;
    showFlavorAndMark?:boolean;
    showCestAndTax?:boolean;
    labelMarkAndFlavor?: "Fardo" | "Unitário" | "Copacker";
}

export const FormProductAttributes =<T extends FieldValues>({mode, methods, labelMarkAndFlavor,showSecondUnitMeasure=false, showFlavorAndMark=false, showCestAndTax=false}:FormProductAttributesProps<T>) => {
    return (
        <div className="flex flex-col w-full">
            <FormSection className="mt-2 md:mt-3 md:flex-row gap-4">
                {/* Unidade de medida*/}
                <Input    
                    label="Unidade de Medida" 
                    name="unidade_medida"
                    register={methods.register("unidade_medida" as Path<T>)}
                    error={methods.formState.errors.unidade_medida?.message as string | undefined} 
                    placeholder="Unidade de medida por extenso. Ex: Unidade(UN)"
                    type="text"
                    icon={UnitMeasureIcon}
                    readOnly={mode === 'viewing' || mode === 'reviewing'}
                />
                {/* segunda unidade de medida*/}
                {showSecondUnitMeasure &&
                    <Input    
                    label="Segunda unidade de Medida" 
                    name="segunda_unidade_medida"
                    register={methods.register("segunda_unidade_medida" as Path<T>)}
                    error={methods.formState.errors.segunda_unidade_medida?.message as string | undefined} 
                    placeholder="Unidade de medida por extenso. Ex: Unidade(UN)"
                    type="text"
                    icon={UnitMeasureIcon}
                    readOnly={mode === 'viewing' || mode === 'reviewing'}
                />
                }
                {/* NCM */}
                {/* Quando Cest e o grupo tributário fazem parte do form, este NCM é ocultado e 
                    outro input com NCM é desocultado para ficar junto na mesma sessão */}
                {!showCestAndTax &&
                    <InputWithMask
                        label="NCM" 
                        name="ncm"
                        maskType="custom"
                        error={methods.formState.errors.ncm?.message as string | undefined} 
                        Icon={NCMIcon}
                        customMask="9999.99.99"
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                }
            </FormSection>

            {/* Sessão sabor e marca */}
            {showFlavorAndMark && 
                <FormSection className="mt-2 md:mt-3 md:flex-row gap-4">
                    {/* Sabor */}
                    <Input    
                        label={labelMarkAndFlavor? `Sabor do ${labelMarkAndFlavor}` : "Sabor"} 
                        name="sabor"
                        register={methods.register("sabor" as Path<T>)}
                        error={methods.formState.errors.sabor?.message as string | undefined} 
                        placeholder="Por favor, insira o sabor"
                        type="text"
                        icon={FlavorIcon}
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                    {/* Marca */}
                    <Input    
                         label={labelMarkAndFlavor? `Marca do ${labelMarkAndFlavor}` : "Marca"} 
                        name="marca"
                        register={methods.register("marca" as Path<T>)}
                        error={methods.formState.errors.marca?.message as string | undefined} 
                        placeholder="Por favor, insira a marca"
                        type="text"
                        icon={MarkIcon}
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                </FormSection>
            }

            {/* Sessão CEST , Grupo Tributário e NCM*/}
            {showCestAndTax && 
                <FormSection className="mt-2 md:mt-3 md:flex-row gap-4">
                    <InputWithMask
                        label="NCM" 
                        name="ncm"
                        maskType="custom"
                        error={methods.formState.errors.ncm?.message as string | undefined} 
                        Icon={NCMIcon}
                        customMask="9999.99.99"
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                    {/* CEST */}
                    <InputWithMask   
                        label="CEST" 
                        name="cest"
                        maskType="custom"
                        error={methods.formState.errors.cest?.message as string | undefined} 
                        Icon={NCMIcon}
                        customMask="99.999.99"   
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                    {/* Grupo Tributário  | Tax Group*/}
                    <Input    
                        label="Grupo Tributário" 
                        name="grupo_tributario"
                        register={methods.register("grupo_tributario" as Path<T>)}
                        error={methods.formState.errors.grupo_tributario?.message as string | undefined} 
                        placeholder="Insira o grupo tributário do produto"
                        type="number"
                        icon={TaxIcon}
                        readOnly={mode === 'viewing' || mode === 'reviewing'}
                    />
                </FormSection>
            }
        </div>
        
    );
};