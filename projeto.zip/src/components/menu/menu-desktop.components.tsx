import {SquareChevronRight as OpenMenuIcon, SquareChevronLeft as CloseMenuIcon} from "lucide-react";
import SymbolLogo from "@/assets/symbol_logo.png";
import { NavMenu } from "./nav-menu.components";
import { NavigationContext } from "@/context";
import {Button} from "@/components";
import { useContext } from "react"


export const Sidebar = () => {
    const {isMenuOpen, toggleOpenMenu, resetPathsMenusAndNavigateDashboard, handleSidebarTransitionEnd} = useContext(NavigationContext);
  
    return (
        <aside
            className={`hidden lg:flex h-screen bg-white-default border-r transition-all duration-300 flex-col z-50 absolute left-0 shadow-[-1px_4px_3px_4px_var(--color-shadow)] ${
                isMenuOpen ? "w-64" : "w-20"}`
            }
            onTransitionEnd={handleSidebarTransitionEnd}
        >
            {/* Topo: Logo + botão toggle */}
            <div className="flex items-center justify-between p-4 relative">
                <div className="flex items-center cursor-pointer" 
                    onClick={resetPathsMenusAndNavigateDashboard}
                >
                    <img src={SymbolLogo} alt="Logo" className="w-10 h-10" />
                    {isMenuOpen && <span className="font-bold text-lg">Cadastro RFK</span>}
                </div>
                <Button 
                    onClick={toggleOpenMenu} 
                    text=""
                    className="ml-5 rounded hover:bg-gray-100 absolute right-0 cursor-pointer"
                    variant="ghost"
                    iconInText={isMenuOpen ? CloseMenuIcon : OpenMenuIcon}
                    styleIcon={{color: isMenuOpen ? "var(--color-strong)":"var(--color-neutral)" , size: 20}}
                />     
            </div>
            <div className="border border-border/70"/>
            
            {/* Menu */}
            <NavMenu/>
            
        </aside>
    );
}

