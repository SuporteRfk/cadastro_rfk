import { AuthContext, NavigationContext } from "@/context";
import {LogOut as LogoutIcon} from "lucide-react";
import { motion } from "framer-motion";
import { useContext } from "react";


export const NavMenu = () => {
    const {menus, lengthMenuCommom, isMenuOpen, handleCategoryClick, activeCategory, handleNavigate, isMenuRouteActive} = useContext(NavigationContext);
    const {logoutService}   = useContext(AuthContext);
    const handleLogout = async() => {
        await logoutService({
            type: "success",
            message: "Sessão encerrada com sucesso"
        });
    }
    return (
        <nav className="h-full p-2 lg:mt-4 flex flex-col items-center justify-center">
            {menus.map((item, i)=> (
                // Categorias e opções sem sub menu 
                <div key={item.label} className="mb-1 w-full">
                    {/* adicionar uma borda para separar o menu comum, como o da controladoria */}
                    {i === lengthMenuCommom && <div className="border border-border my-2"/>}
                        
                    {/* categoria ou item direto */}
                    {item.path ? (
                        <button
                            onClick={() => handleNavigate(item.path!)}
                            title={item.label}
                            className={`
                                flex items-center ${!isMenuOpen ? 'justify-center': 'gap-2'} w-full p-2 rounded hover:bg-accent/30 text-[15px] cursor-pointer
                                ${isMenuRouteActive(item.path!) ? "bg-gray-200 font-semibold" : ""}
                            `}
                        >
                            {<item.icon size={18}/>}
                            {isMenuOpen && (
                                <motion.span
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    transition={{ duration: 1, delay: 0.2 }}
                                >
                                    {item.label}
                                </motion.span>
                            )}
                        </button>
                    ) : (
                        <button
                            onClick={() => handleCategoryClick(item.label)}
                            title={item.label}
                            className={`flex items-center ${!isMenuOpen ? 'justify-center': 'gap-2'} w-full p-2 rounded hover:bg-accent/30 text-[15px] cursor-pointer 
                                ${activeCategory === item.label ? "bg-neutral/40 font-semibold" : ""}`
                            }
                        >
                            <item.icon size={18} />
                            {isMenuOpen && (
                                <motion.span
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    transition={{ duration: 1 , delay: 0.2 }}
                                >
                                    {item.label}
                                </motion.span>
                            )}
                        </button>
                    )}

                    {/* Sub Menus */}
                    {item.children && activeCategory === item.label && (
                        <div className="flex flex-col bg-bg-menu/60 border border-border rounded-b-sm shadow-sm shadow-shadow">
                            {item.children.map((childSubMenu) => (
                                <button
                                    key={childSubMenu.label}
                                    onClick={() => handleNavigate(childSubMenu.path)}
                                    className={`flex items-center w-full p-2 gap-1 rounded hover:bg-accent/20
                                        ${isMenuRouteActive(childSubMenu.path) ? "bg-accent font-semibold text-white-default" : ""}
                                        ${isMenuOpen? 'pl-3' : 'justify-center'}
                                    `}
                                    title={childSubMenu.label}
                                >
                                    <childSubMenu.icon className="w-4 h-4" />
                                    {isMenuOpen  && (
                                        <motion.span
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            exit={{ opacity: 0 }}
                                            transition={{ duration: 1, delay: 0.2 }}
                                            className="text-text-medium text-sm text-nowrap"
                                        >
                                            {childSubMenu.label}
                                        </motion.span>
                                    )}
                                </button>
                            ))}
                        </div>
                    )}
                </div>                
            ))}

            
            <div className="flex-1 flex items-end cursor-pointer w-full mt-1 pt-2 border-t-neutral lg:border-t-border border-t-2">
                <button
                    onClick={handleLogout}
                    className={`flex items-center w-full p-2 gap-1 rounded hover:bg-neutral/20 text-sm text-error/80 font-semibold 
                        ${isMenuOpen? 'lg:pl-4' : 'justify-center'}
                    `}
                    title="Logout"
                >
                    <LogoutIcon className="w-4 h-4" strokeWidth={3}/>
                    {isMenuOpen && (
                        <motion.span
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 1 , delay: 0.2}}
                        >
                         Logout
                       </motion.span>
                    )}
                </button>
            </div>
        </nav>
    );
};